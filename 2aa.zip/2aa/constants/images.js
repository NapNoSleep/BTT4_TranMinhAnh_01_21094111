export const images = {
    Lock: require('../assets/lock.png'),
    Eye: require('../assets/eye.png'),
    AvatarUser: require('../assets/avatar_user.png'),

    USB: require('../assets/usb.png'),
    Start: require('../assets/Star.png'),
    Camera: require('../assets/camera.png'),
    Tick: require('../assets/tick.png'),
    NotTick: require('../assets/notTick.png'),

    Book: require('../assets/book.png'),
    YellowBlock: require('../assets/yellow_block.png'),
};